import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { UserProfile, SIPConfiguration, CallLog, CallStatus } from '@/backend';

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

export function useGetSIPConfiguration() {
  const { actor, isFetching } = useActor();

  return useQuery<SIPConfiguration | null>({
    queryKey: ['sipConfiguration'],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getSIPConfiguration();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useSaveSIPConfiguration() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (config: SIPConfiguration) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveSIPConfiguration(config);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sipConfiguration'] });
    },
  });
}

export function useInitiateCall() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (phoneNumber: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.initiateCall(phoneNumber);
    },
  });
}

export function useAddCallLog() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ phoneNumber, duration, status }: { phoneNumber: string; duration: bigint; status: CallStatus }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addCallLog(phoneNumber, duration, status);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['callLogs'] });
    },
  });
}

export function useGetCallLogs() {
  const { actor, isFetching } = useActor();

  return useQuery<CallLog[]>({
    queryKey: ['callLogs'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getCallLogs();
    },
    enabled: !!actor && !isFetching,
  });
}
