import { useState, useEffect } from 'react';
import { useInternetIdentity } from '@/hooks/useInternetIdentity';
import { useGetCallerUserProfile } from '@/hooks/useQueries';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import LoginPrompt from '@/components/LoginPrompt';
import ProfileSetup from '@/components/ProfileSetup';
import SIPConfigPanel from '@/components/SIPConfigPanel';
import DialPad from '@/components/DialPad';
import CallLogs from '@/components/CallLogs';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function DialerPage() {
  const { identity, isInitializing } = useInternetIdentity();
  const { data: userProfile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();
  const [activeTab, setActiveTab] = useState('dialer');

  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null;

  useEffect(() => {
    if (showProfileSetup) {
      setActiveTab('dialer');
    }
  }, [showProfileSetup]);

  if (isInitializing) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPrompt />;
  }

  if (showProfileSetup) {
    return <ProfileSetup />;
  }

  return (
    <>
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="dialer">Dialer</TabsTrigger>
              <TabsTrigger value="config">SIP Config</TabsTrigger>
              <TabsTrigger value="logs">Call Logs</TabsTrigger>
            </TabsList>
            
            <TabsContent value="dialer" className="space-y-6">
              <DialPad />
            </TabsContent>
            
            <TabsContent value="config" className="space-y-6">
              <SIPConfigPanel />
            </TabsContent>
            
            <TabsContent value="logs" className="space-y-6">
              <CallLogs />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      <Footer />
    </>
  );
}
