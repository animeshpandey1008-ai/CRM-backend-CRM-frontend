import { useInternetIdentity } from '@/hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Phone, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function LoginPrompt() {
  const { login, loginStatus } = useInternetIdentity();

  const handleLogin = async () => {
    try {
      await login();
    } catch (error: any) {
      console.error('Login error:', error);
      toast.error('Failed to login. Please try again.');
    }
  };

  const isLoggingIn = loginStatus === 'logging-in';

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-background via-background to-primary/5">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-primary-foreground shadow-lg">
              <Phone className="h-8 w-8" />
            </div>
          </div>
          <div>
            <CardTitle className="text-2xl">NextGen Dialer</CardTitle>
            <CardDescription className="text-base mt-2">
              VoIP/SIP calling for the modern age
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4 text-center text-sm text-muted-foreground">
            <p>
              Make outbound calls to the USA using CallCentric SIP services with our secure and easy-to-use dialer.
            </p>
            <ul className="text-left space-y-2 max-w-xs mx-auto">
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Configure your SIP credentials</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Make calls with a simple dial pad</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary">•</span>
                <span>Track your call history</span>
              </li>
            </ul>
          </div>
          <Button
            onClick={handleLogin}
            disabled={isLoggingIn}
            size="lg"
            className="w-full"
          >
            {isLoggingIn ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Logging in...
              </>
            ) : (
              'Login to Get Started'
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
