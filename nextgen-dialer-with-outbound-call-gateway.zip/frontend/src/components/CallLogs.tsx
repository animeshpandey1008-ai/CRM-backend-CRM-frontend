import { useGetCallLogs } from '@/hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Phone, PhoneOff, PhoneMissed, Clock, Calendar } from 'lucide-react';
import { CallStatus } from '@/backend';

export default function CallLogs() {
  const { data: callLogs, isLoading } = useGetCallLogs();

  const formatTimestamp = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    return date.toLocaleString();
  };

  const formatDuration = (duration: bigint) => {
    const seconds = Number(duration);
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const getStatusBadge = (status: CallStatus) => {
    switch (status) {
      case CallStatus.completed:
        return (
          <Badge variant="default" className="bg-green-500/20 text-green-500 border-green-500/30">
            <Phone className="h-3 w-3 mr-1" />
            Completed
          </Badge>
        );
      case CallStatus.failed:
        return (
          <Badge variant="destructive">
            <PhoneOff className="h-3 w-3 mr-1" />
            Failed
          </Badge>
        );
      case CallStatus.missed:
        return (
          <Badge variant="secondary">
            <PhoneMissed className="h-3 w-3 mr-1" />
            Missed
          </Badge>
        );
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Call History</CardTitle>
        <CardDescription>
          {callLogs?.length || 0} call{callLogs?.length !== 1 ? 's' : ''} recorded
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!callLogs || callLogs.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Phone className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No call history yet</p>
            <p className="text-sm mt-2">Your calls will appear here</p>
          </div>
        ) : (
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-4">
              {callLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-start justify-between p-4 rounded-lg border border-border bg-card hover:bg-accent/50 transition-colors"
                >
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-primary" />
                      <span className="font-semibold text-lg">{log.phoneNumber}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {formatTimestamp(log.timestamp)}
                      </div>
                      {log.status === CallStatus.completed && (
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatDuration(log.duration)}
                        </div>
                      )}
                    </div>
                  </div>
                  <div>{getStatusBadge(log.status)}</div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
