import { useState, useEffect } from 'react';
import { useGetSIPConfiguration, useInitiateCall, useAddCallLog } from '@/hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Phone, PhoneOff, Delete, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { CallStatus } from '@/backend';

type ConnectionStatus = 'disconnected' | 'connected' | 'calling' | 'in-call' | 'error';

export default function DialPad() {
  const { data: sipConfig } = useGetSIPConfiguration();
  const initiateCall = useInitiateCall();
  const addCallLog = useAddCallLog();

  const [phoneNumber, setPhoneNumber] = useState('');
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [callStartTime, setCallStartTime] = useState<number | null>(null);
  const [callDuration, setCallDuration] = useState(0);

  useEffect(() => {
    if (sipConfig) {
      setStatus('connected');
    } else {
      setStatus('disconnected');
    }
  }, [sipConfig]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (status === 'in-call' && callStartTime) {
      interval = setInterval(() => {
        setCallDuration(Math.floor((Date.now() - callStartTime) / 1000));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [status, callStartTime]);

  const handleNumberClick = (digit: string) => {
    if (status !== 'in-call') {
      setPhoneNumber((prev) => prev + digit);
    }
  };

  const handleDelete = () => {
    setPhoneNumber((prev) => prev.slice(0, -1));
  };

  const handleCall = async () => {
    if (!phoneNumber) {
      toast.error('Please enter a phone number');
      return;
    }

    if (!sipConfig) {
      toast.error('Please configure SIP settings first');
      return;
    }

    try {
      setStatus('calling');
      const result = await initiateCall.mutateAsync(phoneNumber);
      console.log('Call initiated:', result);
      
      setStatus('in-call');
      setCallStartTime(Date.now());
      toast.success('Call connected');
    } catch (error) {
      setStatus('error');
      toast.error('Failed to initiate call');
      console.error(error);
      
      setTimeout(() => {
        setStatus('connected');
      }, 3000);
    }
  };

  const handleHangup = async () => {
    if (status === 'in-call' && callStartTime) {
      const duration = Math.floor((Date.now() - callStartTime) / 1000);
      
      try {
        await addCallLog.mutateAsync({
          phoneNumber,
          duration: BigInt(duration),
          status: CallStatus.completed,
        });
        toast.success('Call ended');
      } catch (error) {
        console.error('Failed to log call:', error);
      }
    }

    setStatus('connected');
    setCallStartTime(null);
    setCallDuration(0);
    setPhoneNumber('');
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getStatusDisplay = () => {
    switch (status) {
      case 'disconnected':
        return { text: 'Not Connected', color: 'text-muted-foreground', icon: AlertCircle };
      case 'connected':
        return { text: 'Ready', color: 'text-green-500', icon: CheckCircle2 };
      case 'calling':
        return { text: 'Calling...', color: 'text-yellow-500', icon: Loader2 };
      case 'in-call':
        return { text: `In Call - ${formatDuration(callDuration)}`, color: 'text-green-500', icon: Phone };
      case 'error':
        return { text: 'Connection Error', color: 'text-destructive', icon: AlertCircle };
    }
  };

  const statusDisplay = getStatusDisplay();
  const StatusIcon = statusDisplay.icon;

  const dialPadButtons = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['*', '0', '#'],
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Dial Pad</CardTitle>
        <CardDescription>Enter a phone number and make a call</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-center gap-2 py-2">
          <StatusIcon className={`h-5 w-5 ${statusDisplay.color} ${status === 'calling' ? 'animate-spin' : ''}`} />
          <span className={`text-sm font-medium ${statusDisplay.color}`}>
            {statusDisplay.text}
          </span>
        </div>

        {status === 'disconnected' && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Please configure your SIP settings in the SIP Config tab before making calls
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-4">
          <div className="relative">
            <Input
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="Enter phone number"
              className="text-center text-2xl h-16 pr-12"
              disabled={status === 'in-call'}
            />
            {phoneNumber && status !== 'in-call' && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2"
                onClick={handleDelete}
              >
                <Delete className="h-5 w-5" />
              </Button>
            )}
          </div>

          <div className="grid grid-cols-3 gap-3">
            {dialPadButtons.map((row, rowIndex) => (
              row.map((digit) => (
                <Button
                  key={`${rowIndex}-${digit}`}
                  variant="outline"
                  size="lg"
                  className="h-16 text-2xl font-semibold"
                  onClick={() => handleNumberClick(digit)}
                  disabled={status === 'in-call' || status === 'disconnected'}
                >
                  {digit}
                </Button>
              ))
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3 pt-4">
            <Button
              size="lg"
              className="h-14"
              onClick={handleCall}
              disabled={status === 'in-call' || status === 'calling' || status === 'disconnected' || !phoneNumber}
            >
              <Phone className="mr-2 h-5 w-5" />
              Call
            </Button>
            <Button
              size="lg"
              variant="destructive"
              className="h-14"
              onClick={handleHangup}
              disabled={status !== 'in-call' && status !== 'calling'}
            >
              <PhoneOff className="mr-2 h-5 w-5" />
              Hang Up
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
