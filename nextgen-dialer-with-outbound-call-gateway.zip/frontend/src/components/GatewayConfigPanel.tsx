import { useState, useEffect } from 'react';
import { useGetSIPGateways, useAddSIPGateway, useUpdateSIPGateway, useDeleteSIPGateway } from '@/hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, Plus, Edit, Trash2, Server, Network, CheckCircle2, XCircle, Clock, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { GatewayStatus, type SIPGateway } from '@/backend';

// Infer Carrier type from SIPGateway
type Carrier = SIPGateway['carrier'];

export default function GatewayConfigPanel() {
  const { data: gateways, isLoading } = useGetSIPGateways();
  const addGateway = useAddSIPGateway();
  const updateGateway = useUpdateSIPGateway();
  const deleteGateway = useDeleteSIPGateway();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGateway, setEditingGateway] = useState<SIPGateway | null>(null);

  // Form state
  const [gatewayId, setGatewayId] = useState('');
  const [name, setName] = useState('');
  const [host, setHost] = useState('');
  const [port, setPort] = useState('5060');
  const [protocol, setProtocol] = useState('UDP');
  const [codecs, setCodecs] = useState('ulaw,alaw,g729');
  const [authUsername, setAuthUsername] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [carrier, setCarrier] = useState<'callcentric' | 'custom'>('callcentric');
  const [status, setStatus] = useState<'active' | 'inactive' | 'failed' | 'pending'>('active');
  const [connectionTimeout, setConnectionTimeout] = useState('30');
  const [retryAttempts, setRetryAttempts] = useState('3');
  const [jitterBuffer, setJitterBuffer] = useState('50');
  const [packetLossTolerance, setPacketLossTolerance] = useState('5');
  const [latencyThreshold, setLatencyThreshold] = useState('150');

  useEffect(() => {
    if (editingGateway) {
      setGatewayId(editingGateway.id);
      setName(editingGateway.name);
      setHost(editingGateway.host);
      setPort(editingGateway.port.toString());
      setProtocol(editingGateway.protocol);
      setCodecs(editingGateway.codecs.join(','));
      setAuthUsername(editingGateway.authUsername);
      setAuthPassword(editingGateway.authPassword);
      // Handle carrier enum properly
      setCarrier(editingGateway.carrier.__kind__ === 'callcentric' ? 'callcentric' : 'custom');
      setStatus(editingGateway.status === GatewayStatus.active ? 'active' : editingGateway.status === GatewayStatus.inactive ? 'inactive' : editingGateway.status === GatewayStatus.failed ? 'failed' : 'pending');
      setConnectionTimeout(editingGateway.connectionTimeout.toString());
      setRetryAttempts(editingGateway.retryAttempts.toString());
      setJitterBuffer(editingGateway.qosParameters.jitterBuffer.toString());
      setPacketLossTolerance(editingGateway.qosParameters.packetLossTolerance.toString());
      setLatencyThreshold(editingGateway.qosParameters.latencyThreshold.toString());
    } else {
      resetForm();
    }
  }, [editingGateway]);

  const resetForm = () => {
    setGatewayId('');
    setName('');
    setHost('');
    setPort('5060');
    setProtocol('UDP');
    setCodecs('ulaw,alaw,g729');
    setAuthUsername('');
    setAuthPassword('');
    setCarrier('callcentric');
    setStatus('active');
    setConnectionTimeout('30');
    setRetryAttempts('3');
    setJitterBuffer('50');
    setPacketLossTolerance('5');
    setLatencyThreshold('150');
  };

  const handleCarrierChange = (value: string) => {
    const newCarrier = value as 'callcentric' | 'custom';
    setCarrier(newCarrier);
    
    if (newCarrier === 'callcentric') {
      setHost('sip.callcentric.net');
      setPort('5060');
      setProtocol('UDP');
      setCodecs('ulaw');
      toast.success('CallCentric defaults applied');
    }
  };

  const handleSave = async () => {
    if (!gatewayId || !name || !host || !port || !authUsername || !authPassword) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const gateway: SIPGateway = {
        id: gatewayId,
        name,
        host,
        port: BigInt(port),
        protocol,
        codecs: codecs.split(',').map(c => c.trim()),
        authUsername,
        authPassword,
        carrier: carrier === 'callcentric' ? { __kind__: 'callcentric' } : { __kind__: 'custom' },
        status: status === 'active' ? GatewayStatus.active : status === 'inactive' ? GatewayStatus.inactive : status === 'failed' ? GatewayStatus.failed : GatewayStatus.pending,
        routingRules: [],
        connectionTimeout: BigInt(connectionTimeout),
        retryAttempts: BigInt(retryAttempts),
        qosParameters: {
          jitterBuffer: BigInt(jitterBuffer),
          packetLossTolerance: BigInt(packetLossTolerance),
          latencyThreshold: BigInt(latencyThreshold),
        },
      };

      if (editingGateway) {
        await updateGateway.mutateAsync(gateway);
        toast.success('Gateway updated successfully');
      } else {
        await addGateway.mutateAsync(gateway);
        toast.success('Gateway added successfully');
      }

      setIsDialogOpen(false);
      setEditingGateway(null);
      resetForm();
    } catch (error) {
      toast.error('Failed to save gateway');
      console.error(error);
    }
  };

  const handleEdit = (gateway: SIPGateway) => {
    setEditingGateway(gateway);
    setIsDialogOpen(true);
  };

  const handleDelete = async (gatewayId: string) => {
    if (!confirm('Are you sure you want to delete this gateway?')) {
      return;
    }

    try {
      await deleteGateway.mutateAsync(gatewayId);
      toast.success('Gateway deleted successfully');
    } catch (error) {
      toast.error('Failed to delete gateway');
      console.error(error);
    }
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
    setEditingGateway(null);
    resetForm();
  };

  const getStatusBadge = (status: GatewayStatus) => {
    switch (status) {
      case GatewayStatus.active:
        return <Badge variant="default" className="gap-1 bg-green-500"><CheckCircle2 className="h-3 w-3" />Active</Badge>;
      case GatewayStatus.inactive:
        return <Badge variant="outline" className="gap-1"><XCircle className="h-3 w-3" />Inactive</Badge>;
      case GatewayStatus.failed:
        return <Badge variant="destructive" className="gap-1"><AlertCircle className="h-3 w-3" />Failed</Badge>;
      case GatewayStatus.pending:
        return <Badge variant="outline" className="gap-1"><Clock className="h-3 w-3" />Pending</Badge>;
    }
  };

  const getCarrierLabel = (carrier: Carrier): string => {
    return carrier.__kind__ === 'callcentric' ? 'CallCentric' : 'Custom';
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Network className="h-5 w-5 text-primary" />
            <div>
              <CardTitle>Gateway Administration</CardTitle>
              <CardDescription>
                Manage SIP gateways for outbound call routing
              </CardDescription>
            </div>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => setEditingGateway(null)}>
                <Plus className="mr-2 h-4 w-4" />
                Add Gateway
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingGateway ? 'Edit Gateway' : 'Add New Gateway'}</DialogTitle>
                <DialogDescription>
                  Configure SIP gateway settings for outbound call routing
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="gatewayId">Gateway ID *</Label>
                    <Input
                      id="gatewayId"
                      placeholder="gateway-1"
                      value={gatewayId}
                      onChange={(e) => setGatewayId(e.target.value)}
                      disabled={!!editingGateway}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="name">Gateway Name *</Label>
                    <Input
                      id="name"
                      placeholder="CallCentric Primary"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="carrier">Carrier *</Label>
                  <Select value={carrier} onValueChange={handleCarrierChange}>
                    <SelectTrigger id="carrier">
                      <SelectValue placeholder="Select carrier" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="callcentric">CallCentric</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="host">SIP Proxy Host *</Label>
                    <Input
                      id="host"
                      placeholder="sip.callcentric.net"
                      value={host}
                      onChange={(e) => setHost(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="port">Outbound Port *</Label>
                    <Input
                      id="port"
                      type="number"
                      placeholder="5060"
                      value={port}
                      onChange={(e) => setPort(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="protocol">Protocol</Label>
                  <Select value={protocol} onValueChange={setProtocol}>
                    <SelectTrigger id="protocol">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UDP">UDP</SelectItem>
                      <SelectItem value="TCP">TCP</SelectItem>
                      <SelectItem value="TLS">TLS</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="codecs">Codecs (comma-separated) *</Label>
                  <Input
                    id="codecs"
                    placeholder="ulaw,alaw,g729"
                    value={codecs}
                    onChange={(e) => setCodecs(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Recommended: ulaw for CallCentric
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="authUsername">Auth Username *</Label>
                    <Input
                      id="authUsername"
                      placeholder="1777MYCCID"
                      value={authUsername}
                      onChange={(e) => setAuthUsername(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="authPassword">Auth Password *</Label>
                    <Input
                      id="authPassword"
                      type="password"
                      placeholder="Your gateway password"
                      value={authPassword}
                      onChange={(e) => setAuthPassword(e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="status">Gateway Status</Label>
                  <Select value={status} onValueChange={(v) => setStatus(v as any)}>
                    <SelectTrigger id="status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="border-t pt-4 space-y-4">
                  <h4 className="text-sm font-semibold">Connection Settings</h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="connectionTimeout">Connection Timeout (seconds)</Label>
                      <Input
                        id="connectionTimeout"
                        type="number"
                        value={connectionTimeout}
                        onChange={(e) => setConnectionTimeout(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="retryAttempts">Retry Attempts</Label>
                      <Input
                        id="retryAttempts"
                        type="number"
                        value={retryAttempts}
                        onChange={(e) => setRetryAttempts(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4 space-y-4">
                  <h4 className="text-sm font-semibold">Quality of Service (QoS)</h4>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="jitterBuffer">Jitter Buffer (ms)</Label>
                      <Input
                        id="jitterBuffer"
                        type="number"
                        value={jitterBuffer}
                        onChange={(e) => setJitterBuffer(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="packetLossTolerance">Packet Loss (%)</Label>
                      <Input
                        id="packetLossTolerance"
                        type="number"
                        value={packetLossTolerance}
                        onChange={(e) => setPacketLossTolerance(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="latencyThreshold">Latency (ms)</Label>
                      <Input
                        id="latencyThreshold"
                        type="number"
                        value={latencyThreshold}
                        onChange={(e) => setLatencyThreshold(e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={handleDialogClose}>
                  Cancel
                </Button>
                <Button onClick={handleSave} disabled={addGateway.isPending || updateGateway.isPending}>
                  {(addGateway.isPending || updateGateway.isPending) ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    'Save Gateway'
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {gateways && gateways.length > 0 ? (
          <>
            <Alert className="bg-accent/50 border-accent">
              <Server className="h-4 w-4 text-accent-foreground" />
              <AlertDescription className="text-accent-foreground">
                {gateways.filter(g => g.status === GatewayStatus.active).length} active gateway(s) configured for outbound routing
              </AlertDescription>
            </Alert>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Host</TableHead>
                    <TableHead>Carrier</TableHead>
                    <TableHead>Codecs</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {gateways.map((gateway) => (
                    <TableRow key={gateway.id}>
                      <TableCell className="font-medium">{gateway.name}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{gateway.host}:{gateway.port.toString()}</div>
                          <div className="text-muted-foreground">{gateway.protocol}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {getCarrierLabel(gateway.carrier)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="text-xs text-muted-foreground">
                          {gateway.codecs.join(', ')}
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(gateway.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEdit(gateway)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(gateway.id)}
                            disabled={deleteGateway.isPending}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </>
        ) : (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              No gateways configured. Add a gateway to enable outbound call routing.
            </AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );
}
