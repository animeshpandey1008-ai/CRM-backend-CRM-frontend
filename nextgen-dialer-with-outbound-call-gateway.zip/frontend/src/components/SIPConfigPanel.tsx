import { useState, useEffect } from 'react';
import { useGetSIPConfiguration, useSaveSIPConfiguration } from '@/hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, CheckCircle2, Server } from 'lucide-react';
import { toast } from 'sonner';

export default function SIPConfigPanel() {
  const { data: sipConfig, isLoading } = useGetSIPConfiguration();
  const saveSIPConfig = useSaveSIPConfiguration();

  const [server, setServer] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [port, setPort] = useState('5060');
  const [displayName, setDisplayName] = useState('');

  useEffect(() => {
    if (sipConfig) {
      setServer(sipConfig.server);
      setUsername(sipConfig.username);
      setPassword(sipConfig.password);
      setPort(sipConfig.port.toString());
      setDisplayName(sipConfig.displayName || '');
    }
  }, [sipConfig]);

  const handleSave = async () => {
    if (!server || !username || !password || !port) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      await saveSIPConfig.mutateAsync({
        server,
        username,
        password,
        port: BigInt(port),
        displayName: displayName || undefined,
      });
      toast.success('SIP configuration saved successfully');
    } catch (error) {
      toast.error('Failed to save SIP configuration');
      console.error(error);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Server className="h-5 w-5 text-primary" />
          <CardTitle>SIP Configuration</CardTitle>
        </div>
        <CardDescription>
          Configure your CallCentric SIP/VoIP settings for outbound calls to the USA
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {sipConfig && (
          <Alert className="bg-accent/50 border-accent">
            <CheckCircle2 className="h-4 w-4 text-accent-foreground" />
            <AlertDescription className="text-accent-foreground">
              SIP configuration is active and ready for calls
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="server">SIP Server/Domain *</Label>
            <Input
              id="server"
              placeholder="sip.callcentric.com"
              value={server}
              onChange={(e) => setServer(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="username">Username *</Label>
            <Input
              id="username"
              placeholder="Your SIP username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password *</Label>
            <Input
              id="password"
              type="password"
              placeholder="Your SIP password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="port">Port *</Label>
            <Input
              id="port"
              type="number"
              placeholder="5060"
              value={port}
              onChange={(e) => setPort(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">Default SIP port is 5060</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="displayName">Display Name (Optional)</Label>
            <Input
              id="displayName"
              placeholder="Your caller ID name"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
            />
          </div>
        </div>

        <Button
          onClick={handleSave}
          disabled={saveSIPConfig.isPending}
          className="w-full"
        >
          {saveSIPConfig.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            'Save Configuration'
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
